#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	double number;
	double squareRoot;
	
	number = 25.0;
	
	squareRoot = sqrt(number);
	
	cout<<"Square root of "<<number<<" = "<<squareRoot;
	
	return 0;
}
